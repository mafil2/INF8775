#!/bin/sh

./main "$@"

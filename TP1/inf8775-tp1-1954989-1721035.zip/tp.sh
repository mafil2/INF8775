#!/bin/sh
./main "$@"
